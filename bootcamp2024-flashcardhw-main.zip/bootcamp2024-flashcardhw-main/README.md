# bootcamp2024-flashcardhw
For our homework, we are creating a flashcard app! When you click the card, it should show the definition. You can also go to the next card or previous card. If you keep pressing next, it should loop back to the first card and vice-versa. Also, you need to create the ability to add more cards if needed. Please stop by office hours if needed.
